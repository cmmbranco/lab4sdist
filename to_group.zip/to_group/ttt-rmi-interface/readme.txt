This small library contains the RMI interface of the Tic Tac Toe game.

The interface is shared by the server, that implements it, and
by the client, that needs it to generate a proxy.


Instructions using Maven:
------------------------

To compile and install:
  mvn install


To configure the Maven project in Eclipse:
-----------------------------------------

'File', 'Import...', 'Maven'-'Existing Maven Projects'
'Select root directory' and 'Browse' to the project base folder.
Check that the desired POM is selected and 'Finish'.


--
Revision date: 2018-03-03
leic-sod@disciplinas.tecnico.ulisboa.pt
